<?php

include('s_dbconnection.php');
include('s_header.php');
?>




<?php
include('footer.php');
include('script.php');
?>